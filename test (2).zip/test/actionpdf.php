<?php
require('fpdf17/fpdf.php');

$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0, 10, "Infotek Soluton regstratoin ", 1, 0,'C');

$pdf->Cell(60, 10, "Name: " , 1, 0);
$pdf->Cell(60, 10, $_POST['name'], 1, 1);

$pdf->Cell(60, 10, "Email: ", 1, 0);
$pdf->Cell(60, 10, $_POST['email'], 1,1 );

$pdf->Cell(60, 10, "URL: ", 1, 0);
$pdf->Cell(60, 10, $_POST['url'], 1, 1);

$pdf->Cell(60, 10, "Comment: ", 1, 0);
$pdf->Cell(60, 10, $_POST['comment'], 1, 1);


$pdf->output($_POST['name'].'.pdf', 'F');
?>