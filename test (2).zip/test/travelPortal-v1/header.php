<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Select a Flight: Mercury Tours</title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: green; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FF6692"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#88888" link="#99777" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#006699">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#006699">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#11111111"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="book.php">Flight</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Hotel</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#000000"><a href="inprogress.php">Car Rent</a></font></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Vacation</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>ABCD ABCD</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#006699" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ON</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTER</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>




<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>