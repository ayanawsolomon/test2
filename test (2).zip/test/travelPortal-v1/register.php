<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Register: Mercury Tours</title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: green; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FF6692"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#88888" link="#99777" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#006699">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#006699">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#11111111"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="book.php">Flight</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Hotel</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#000000"><a href="inprogress.php">Car Rent</a></font></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Vacation</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>ABCD ABCD</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#006699" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ON</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTER</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>




<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>

<!--CONTENT REGION START-->
				<table cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
				  <td width="14">
				    
				  </td>
				<td>


<table width="492" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr> 
    <td><img src="Register%20%20Mercury%20Tours_files/mast_register.gif" width="492" height="30"></td>
  </tr>
  <tr> 
    <td><img src="Register%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr> 
    <td> 
      <p><font size="2" face="Arial, Helvetica, sans-serif">Plese fill the required filed<font color="red">(*) </font>below to complete your registration.</font>

    </p></td>
  </tr>
  <tr>
    <td><img src="Register%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr> 
    <td> 
      <form method="post" action="scripts/register1.php">
	<input name="mercury" value="process" type="hidden">
        <table width="100%" cellpadding="2" border="0">
          <tbody><tr bgcolor="#CCCCCC"> 
            <td colspan="2"><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="white"> 
              <b>&nbsp;&nbsp;<font color="#FFFFFF"><font size="2" color="#000000" face="ARIAL, HELVETICA">Personal Information 
              </font></font></b></font></font></td>

          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>First Name 
              : </b></font></td>
            <td> 
              <input maxlength="60" name="firstName" size="20"><font color="red">*</font>
            </td>
          </tr>
		  
		  <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Middle Inital 
              : </b></font></td>
            <td> 
              <input maxlength="60" name="midleInitial" size="20">
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Last Name: </b></font></td>

            <td> 
              <input maxlength="60" name="lastName" size="20"><font color="red">*</font>
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Mobile:</b></font></td>
            <td> 
              <input maxlength="20" name="phone" size="15">
            </td>
          </tr>

          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>E-mail:</b></font></td>
            <td> 
              <input name="email" id="userName" size="35" maxlength="64" disabled>
            </td>
          </tr>
          <tr bgcolor="#CCCCCC"> 
            <td colspan="2"><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="white"><b>&nbsp;&nbsp;<font color="#003399"><font size="2" color="#000000" face="ARIAL, HELVETICA">Address Information</font></font></b></font></font></td>
          </tr>

          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Street:</b></font></td>
            <td> 
              <input maxlength="60" name="address1" size="40">
            </td>
          </tr>
          <tr> 
            <td><font size="2" face="Arial, Helvetica, sans-serif">&nbsp;</font></td>
            <td> 
              <input maxlength="60" size="40" name="address2">

            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>City:</b></font></td>
            <td> 
              <input maxlength="60" name="city" size="15">
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>State/Region:</b></font></td>

            <td> 
              <input maxlength="40" name="state">
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Po.Box/Postal-Code:</b></font></td>
            <td> 
              <input maxlength="20" name="postalCode" size="15">
            </td>
          </tr>

          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Country:</b></font></td>
            <td> 
              <select name="country" size="1">
                <option value="2">Ethiopia </option>
                <option value="3">India </option>
                <option value="7">Canada </option>
                <option value="4">USA </option>

                <option value="251">Brazil </option>
                <option value="10">Gahana </option>
                <option value="234">Senegal </option>
                <option value="1">Nepal</option>
                <option value="8">Denmark </option>
                <option value="243">Eriteria </option>

                <option value="236">Japan </option>
                <option value="5">German </option>
                <option value="6">AUSTRALIA </option>
                <option value="9">AUSTRIA </option>
               

                <option value="73">GIBRALTAR </option>
                <option value="74">GLORIOSO ISLANDS </option>
                <option value="75">GREECE </option>
                <option value="76">GREENLAND </option>
                <option value="77">GRENADA </option>
                <option value="78">GUADELOUPE </option>

                <option value="79">GUAM </option>
                <option value="80">GUATEMALA </option>
                <option value="81">GUERNSEY </option>
                <option value="82">GUINEA </option>
                <option value="83">GUINEA-BISSAU </option>
                <option value="84">GUYANA </option>

                <option value="85">HAITI </option>
                <option value="86">HEARD ISLAND AND MCDONALD ISLANDS </option>
                <option value="87">HONDURAS </option>
                <option value="88">HONG KONG </option>
                <option value="89">HOWLAND ISLAND </option>
                <option value="90">HUNGARY </option>

                <option value="91">ICELAND </option>
                <option value="92">INDIA </option>
                <option value="93">INDONESIA </option>
                <option value="254">IRAN </option>
                <option value="255">IRAQ </option>
                <option value="94">IRELAND </option>

                <option value="95">ISRAEL </option>
                <option value="96">ITALY </option>
                <option value="98">JAMAICA </option>
                <option value="99">JAN MAYEN </option>
                <option value="100">JAPAN </option>
                <option value="101">JARVIS ISLAND </option>

               
                <option value="264">MACEDONIA, FORMER REPUBLIC OF </option>
              
                <option value="228">ZAIRE </option>

                <option value="229">ZAMBIA </option>
                <option value="230">ZIMBABWE </option>
              </select>
            </td>
          </tr>
          <tr bgcolor="#CCCCCC"> 
            <td colspan="2"> <font helvetica="helvetica" size="2" face="Arial, Helvetica, sans-serif"><font color="white"><b>&nbsp;&nbsp;<font color="#000000">User 
              Login/Account Records </font> </b></font></font></td>

          </tr>
          <tr> 
            <td align="right"><font size="2" color="red" face="Arial, Helvetica, sans-serif"><b>Login 
              Name :</b></font></td>
            <td> 
              <input name="loginName" id="email" size="20" maxlength="60"><font color="red">*</font>
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" color="red" face="Arial, Helvetica, sans-serif"><b>Login Pass :</b></font></td>

            <td> 
              <input maxlength="60" name="password" size="20" type="password"><font color="red">*</font>
            </td>
          </tr>
          <tr> 
            <td align="right"><font size="2" color="red" face="Arial, Helvetica, sans-serif"><b>Re-type 
              Password: </b></font></td>
            <td> 
              <input maxlength="60" name="confirmPassword" size="20" type="password"><font color="red">*</font>
            </td>
          </tr>

          <tr> 
            <td colspan="2" align="CENTER"><img src="Register%20%20Mercury%20Tours_files/spacer.htm" width="1" height="2"></td>
          </tr>
          <tr> 
            <td colspan="2" align="CENTER"> &nbsp;&nbsp;<input name="register" src="Register%20%20Mercury%20Tours_files/submit.gif" width="60" type="image" height="23" border="0"></td>
          </tr>
        </tbody></table>
      </form>
    </td>

  </tr>
</tbody></table>
<p>&nbsp;</p>

				</td>
				</tr>
				</tbody></table>

<!--CONTENT REGION END-->

        </td>
      </tr>

     <tr>
      <td>

<!--FOOTER REGION START-->


<!--FOOTER REGION START-->
<div class="footer">
� 2017, Solo Travel Portal(v. 301-73X-3908)
</div>
<!--FOOTER REGION END-->


<!--FOOTER REGION END-->

      </td>
     </tr>
      
    
  </tbody></table>
</td></tr></tbody></table>
</div>


</body></html>