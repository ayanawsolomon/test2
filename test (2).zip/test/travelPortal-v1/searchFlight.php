<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Find a Flight: Mercury Tours: </title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: green; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FF6692"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#88888" link="#99777" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#006699">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#006699">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#11111111"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="book.php">Flight</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Hotel</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#000000"><a href="inprogress.php">Car Rent</a></font></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Vacation</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>ABCD ABCD</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#006699" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ON</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTER</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>
<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>

<!--CONTENT REGION START-->
				<table cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
				  <td width="14">
				    
				  </td>
				<td>


<table width="492" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>     <td><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/mast_flightfinder.gif" width="492" height="30"></td>
  </tr>
  <tr>
     <td><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr>
    <td><font size="2" face="Arial, Helvetica, sans-serif">Use our Flight Finder
       to search for the lowest fare on participating airlines. Once you've booked 
      your flight, don't forget to visit the Mercury Tours Hotel Finder to reserve 
      lodging in your destination city.</font></td>

  </tr>
  <tr>
    <td><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr> 
    <td> 
      <form method="post" action="selectFlight.php" name="findflight">
        <table width="100%" cellpadding="2" border="0">
          <tbody><tr> 
            <td colspan="2" bgcolor="#CCCCCC"><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="white"> 
              <b>&nbsp;&nbsp;<font color="#FFFFFF"><font size="2" color="#000000" face="ARIAL, HELVETICA">Flight 
              Details </font></font></b></font></font></td>

          </tr>
          <tr> 
            <td width="33%" align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Type:</b></font></td>
            <td width="67%"><b><font size="2" face="Arial, Helvetica, sans-serif"> 
              <input name="tripType" value="roundtrip" checked="checked" type="radio">
              Round Trip &nbsp; 
              <input name="tripType" value="oneway" type="radio">
              One Way</font></b></td>
          </tr>

          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Passengers:</b></font></td>
            <td><b> 
              <select name="passCount">
                <option value="1" selected="selected">1 </option>
                <option value="2">2 </option>
                <option value="3">3 </option>
                <option value="4">4 </option>

              </select>
              </b></td>
          </tr>
          <tr> <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Departing 
              From: </b></font></td>
            <td>
<select name="fromPort">
<option value="Acapulco" selected="selected">Acapulco
</option><option value="Frankfurt">Frankfurt
</option><option value="London">London
</option><option value="New York">New York
</option><option value="Paris">Paris
</option><option value="Portland">Portland
</option><option value="San Francisco">San Francisco
</option><option value="Seattle">Seattle
</option><option value="Sydney">Sydney
</option><option value="Zurich">Zurich
</option></select>
</td>        </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>On:</b></font></td>
            <td> 
<select name="fromMonth">
<option value="1">January
</option><option value="2">February
</option><option value="3">March
</option><option value="4">April
</option><option value="5">May
</option><option value="6">June
</option><option selected="selected" value="7">July
</option><option value="8">August
</option><option value="9">September
</option><option value="10">October
</option><option value="11">November
</option><option value="12">December
</option></select>
<select name="fromDay">
<option value="1">1
</option><option value="2">2
</option><option value="3">3
</option><option value="4">4
</option><option value="5">5
</option><option selected="selected" value="6">6
</option><option value="7">7
</option><option value="8">8
</option><option value="9">9
</option><option value="10">10
</option><option value="11">11
</option><option value="12">12
</option><option value="13">13
</option><option value="14">14
</option><option value="15">15

</option><option value="27">27
</option><option value="28">28
</option><option value="29">29
</option><option value="30">30
</option><option value="31">31
</option></select>

<applet code="showCalendar.class" mayscript="" width="114" height="20">
<param name="HtmlTitleName" value="Select Departure Date">
<param name="HtmlMonthName" value="fromMonth">
<param name="HtmlDayName" value="fromDay">
</applet> 
          </td>

          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Arriving 
              In: </b></font></td>
            <td>
<select name="toPort">
<option value="Acapulco" selected="selected">Acapulco
</option><option value="Frankfurt">Frankfurt
</option><option value="London">London
</option><option value="New York">New York
</option><option value="Paris">Paris
</option><option value="Portland">Portland
</option><option value="San Francisco">San Francisco
</option><option value="Seattle">Seattle
</option><option value="Sydney">Sydney
</option><option value="Zurich">Zurich
</option></select>
</td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Returning:</b></font></td>
            <td>
<select name="toMonth">
<option value="1">January
</option><option value="2">February
</option><option value="3">March
</option><option value="4">April
</option><option value="5">May
</option><option value="6">June
</option><option selected="selected" value="7">July
</option><option value="8">August
</option><option value="9">September
</option><option value="10">October
</option><option value="11">November
</option><option value="12">December
</option></select>
<select name="toDay">
<option value="1">1
</option><option value="2">2
</option><option value="3">3
</option><option value="4">4
</option><option value="5">5
</option><option selected="selected" value="6">6
</option><option value="7">7
</option><option value="8">8
</option><option value="9">9
</option><option value="10">10
</option><option value="11">11
</option><option value="12">12
</option><option value="13">13
</option><option value="14">14
</option><option value="15">15
</option><option value="16">16
</option><option value="17">17
</option><option value="18">18
</option><option value="19">19
</option><option value="20">20
</option><option value="21">21
</option><option value="22">22
</option><option value="23">23
</option><option value="24">24
</option><option value="25">25
</option><option value="26">26
</option><option value="27">27
</option><option value="28">28
</option><option value="29">29
</option><option value="30">30
</option><option value="31">31
</option></select>

<font size="2" face="Arial, Helvetica, sans-serif">
<applet code="showCalendar.class" mayscript="" width="114" height="20">
<param name="HtmlTitleName" value="Select Arrivale Date">
<param name="HtmlMonthName" value="toMonth">
<param name="HtmlDayName" value="toDay">
</applet> 
              </font> </td>
          </tr>

          <tr> 
            <td colspan="2" bgcolor="#CCCCCC"><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="white"><b>&nbsp;&nbsp;<font color="#003399"><font size="2" color="#000000" face="ARIAL, HELVETICA">Preferences</font></font></b></font></font></td>
          </tr>
          <tr> 
            <td valign="top" align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Service 
              Class: </b></font></td>
            <td> <font size="2"> 
              <input checked="checked" name="servClass" value="Coach" type="radio">
              <font face="Arial, Helvetica, sans-serif">Economy class <br>

              <input name="servClass" value="Business" type="radio">
              Business class <br>
              <input name="servClass" value="First" type="radio">
              First class</font></font></td>
          </tr>
          <tr> 
            <td align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>Airline:</b></font></td>
            <td> 
              <select name="airline">

                <option selected="selected">No Preference</option>
                <option>Blue Skies Airlines</option>
                <option>Unified Airlines</option>
                <option>Pangea Airlines</option>
              </select>
            </td>
          </tr>

          <tr> 
            <td colspan="2"><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="2"></td>
          </tr>
          <tr bgcolor="#CCCCCC"> 
            <td colspan="2" align="CENTER"><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="1"></td>
          </tr>
          <tr> 
            <td colspan="2"><img src="Find%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="2"></td>
          </tr>
          <tr> 
            <td colspan="2" align="CENTER"> &nbsp;&nbsp;<input name="findFlights" src="Find%20a%20Flight%20%20Mercury%20Tours_files/continue.gif" width="104" type="image" height="23" border="0"></td>

          </tr>
        </tbody></table>
      </form>
    </td>
  </tr>
</tbody></table>

				</td>
				</tr>
				</tbody></table>

<!--CONTENT REGION END-->

        </td>
      </tr>
     <tr>
      <td>

<!--FOOTER REGION START-->


<!--FOOTER REGION START-->
<div class="footer">

© 2005, Mercury Interactive (v. 011003-1.01-058)
</div>
<!--FOOTER REGION END-->


<!--FOOTER REGION END-->

      </td>
     </tr>
      
    
  </tbody></table>

</td></tr></tbody></table>
</div>


</body></html>