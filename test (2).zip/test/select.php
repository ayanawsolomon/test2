<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";
$dCustomerID=$_POST["dCustomerID"];
// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record

$sql = "SELECT * FROM customers WHERE customerID='$dCustomerID'";

$result = $conn->query($sql);
echo $sql;
if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "<tr><td>".$row['CustomerID']."</td><td>".$row['CustomerName']."-=- ".$row['Address']. " -=-".$row['City']. "-=- ".$row['Country']."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>