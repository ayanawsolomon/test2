<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
function showValue(newValue)
{
	document.getElementById("range").innerHTML=newValue;
}
</script>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
</head>
<body>
<a href="testPage.php">Back to Test Page 1 </a>
<br/>
<hr/>
<h4> HTML Icons </h4>
<i class="fa fa-cloud"></i>
<i class="fa fa-heart" data-toggle="tooltip" title="heart"></i>
<i class="fa fa-car" data-toggle="tooltip" title="choose car"></i>
<i class="fa fa-file" data-toggle="tooltip" title="open file"></i>
<i class="fa fa-bars" data-toggle="tooltip" title="menu"></i>
<i class="fa fa-print" onclick ="window.print()"   data-toggle="tooltip" title="print"></i>
<i class="fa fa-back"></i>
<i class="fa fa-bicycle"></i>
<i class="fa fa-cut" data-toggle="tooltip" title="cut"></i>
<i class="fa fa-copy" data-toggle="tooltip" title="coppy"></i>
<i class="fa fa-pest"></i>
<i class="fa fa-find"></i>
<i class="fa fa-undo" data-toggle="tooltip" title="undo"></i>
<i class="fa fa-redo" data-toggle="tooltip" title="redo"></i>








<hr/>
<h2>Toggle Switch</h2>

<label class="switch">
  <input type="checkbox">
  <span class="slider"></span>
</label>
<br/>

<label class="switch">
  <input type="checkbox" checked>
  <span class="slider"></span>
</label><br><br>
<br/>
Do you need Welchair? 

<label class="switch">
  <input type="checkbox">
  <span class="slider round"></span>
</label>
<br/>
Do you need guider? 
<label class="switch">
  <br/><input type="checkbox" checked>
  <span class="slider round"></span>
</label>

<br/>
<div class="container">
  <h2>Modal Element Example</h2>
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Login Here</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login</h4>
        </div>
        <div class="modal-body">
		<input name="userName" type="text" value="user Name"/><br/>
		<input name="password" type ="password" value ="password"/><br/>
        </div>
        <div class="modal-footer">
          <button  type="button" name ="singin" class="btn btn-default" data-dismiss="modal">Login</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>


<br/>
<hr/>
<table>
<tr>
<td>
 <table border='1'  bordercolor='#FFFF00' cellspacing='0' cellpadding='0' align=center>
<tr><td><table cellspacing='0' cellpadding='0' align=center width='100' border='1'><tr><td  align=center bgcolor='#ffff00'><font size='2' face='Tahoma'> <a href='html_calendar.php?prm=07&chm=-1' rel="nofollow"><</a></font> </td><td colspan=5 align=center bgcolor='#ffff00'><font size='2' face='Tahoma'>Jul 2017 </font> </td><td  align=center bgcolor='#ffff00'><font size='2' face='Tahoma'> <a href='html_calendar.php?prm=07&chm=1' rel="nofollow">></a>  </font></td></tr><tr><td><font size='2' face='Tahoma'><b>Sun</b></font></td><td><font size='2' face='Tahoma'><b>Mon</b></font></td><td><font size='2' face='Tahoma'><b>Tue</b></font></td><td><font size='2' face='Tahoma'><b>Wed</b></font></td><td><font size='2' face='Tahoma'><b>Thu</b></font></td><td><font size='2' face='Tahoma'><b>Fri</b></font></td><td><font size='2' face='Tahoma'><b>Sat</b></font></td></tr><tr><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td><td valign=top><font size='2' face='Tahoma'>1  
<br>
 </font></td></tr><tr><td valign=top><font size='2' face='Tahoma'>2  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>3  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>4  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>5  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>6  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>7  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>8  
<br>
 </font></td></tr><tr><td valign=top><font size='2' face='Tahoma'>9  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>10  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>11  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>12  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>13  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>14  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>15  
<br>
 </font></td></tr><tr><td valign=top><font size='2' face='Tahoma'>16  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>17  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>18  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>19  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>20  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>21  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>22  
<br>
 </font></td></tr><tr><td valign=top><font size='2' face='Tahoma'>23  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>24  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>25  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>26fgfhsg 
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>27  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>28  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>2  
<br>
 </font></td></tr><tr><td valign=top><font size='2' face='Tahoma'>30  
<br>
 </font></td><td valign=top><font size='2' face='Tahoma'>31  
<br>
 </font></td></tr></table></td></tr></table>
 </td> 
 <td>
 <img src="../img/habeshaschool.png" alt="sorry image not ready yet" height="100" width="100">
</td>
<td> 
<br/>
tip: <input type="range" min="0" max="100" value="0" step="5" onchange="showValue(this.value)" />
$<span id="range">0</span>
<br/>

</td>

<td>
 <img src="../img/SoftwareTestingTypes.jpg" alt="sorry image not ready yet" height="500" width="500">
</td>

 </tr>
 </table>
<hr/>
</body>
</html> 
