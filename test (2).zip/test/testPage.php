<!DOCTYPE HTML>  
<html>
<head>
<script>
function alertMe() {
    alert(" Good moringsdf sdfsd sdf Hello\nHow are you?\n Alert from Solomon A");
	document.getElementById("demo").innerHTML = "You accepted the alert.";
}
function confirmMe() {
    var txt;
    var r = confirm("Press a button!\n Confirmation from Solomon A.");
    if (r == true) {
        txt = "You pressed OK!";
    } else {
        txt = "You pressed Cancel!";
    }
    document.getElementById("demo").innerHTML = txt;
}

function promptMe() {
    var person = prompt("Please enter your name", "Solomon A");
    if (person != null) {
        document.getElementById("demo").innerHTML =
        "Hello " + person + "! How are you today?";
    }
}



</script>

<style>
.error {color: #FF0000;}
.special { color: #FF9809;}
a:hover { 
    background-color: yellow;
}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = $countryErr="";
$name = $email = $gender = $comment = $website = $country= $vechicle="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
    
  if (empty($_POST["website"])) {
    $website = "";
  } else {
    $website = test_input($_POST["website"]);
    // check if URL address syntax is valid
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
      $websiteErr = "Invalid URL"; 
    }    
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
	  $comment = $_POST["comment"];
   // $comment = test_input($_POST["comment"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
   $country = test_input($_POST["country"]);

   if(isset($_POST['bike'])){
   $vechicle = $vechicle . "Bike";
   }
   if(isset($_POST['car'])){
   $vechicle = $vechicle . " Car";
   }
    if(isset($_POST['boat'])){
   $vechicle = $vechicle . " Boat";
   }
    if(isset($_POST['horse'])){
   $vechicle = $vechicle . " Horse";
   }

   
   }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
||<a href="testPage.php">Test 1</a>||
<a href="testPage2.php">Test 2</a>  ||  
<a href="calculator.html">Open Calculator </a>  ||  
<a href="register.html">Register</a>  || 
<a href="search-form.php">Search </a>  ||
 
<a href ="questions.php"> Question and Answer </a> || 
<a href ="moreElements.php"> More Elements </a> || 

<a href ="toPDFMain.php"> Create PDF </a> ||

<hr/>
<h1>Test Page1 for Testing</h1>
<hr/>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"> 
  Name: <input type="text" name="name"     value="Solomon">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail       : <input type="text" id="eml" name="email" >
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Website: <input type="text" name="website">
  <span class="error"><?php echo $websiteErr;?></span>
  <br><br>
  Comment: <textarea name="comment" rows="4" cols="30"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female</input>
  <input type="radio" name="gender" value="male">Male</input>
   <input type="radio" id="other" name="gender" value="Other">Other</input>
  <span class="error">* <?php echo $genderErr;?></span>
</br></br>
 What do you have:  <input type="checkbox" name="bike" value="Bike"> Bike
  <input type="checkbox" name="car" value="car" checked> Car
 <input type="checkbox" name="boat" value="boat" > Boat
  <input type="checkbox" name="horse" value="horse" > Horse
  <br><br>
  Country:
  <select name="country">
  <option value="USA">USA</option>
  <option value="INDIA">India</option>
  <option value="ETHIOPIA">Ethiopia</option>
  <option value="FRANCE">France</option>
  <option value ="Egypt">Egypt</option>
   
</select>
<span class="error">* <?php echo $countryErr;?></span>
</br>
Skill:
  <select name="skill" multiple>
  <option value="qa">Quality Assurance</option>
  <option value="prg">Programming</option>
  <option value="db">Database</option>
  <option value="ba">Business Administration</option>
  <option value="mgmt">Management</option>
   
</select>

</br>
</br>
  <input type="submit" name="submit" class= "special" value="Send" data-toggle="tooltip" title="click to submitdfgsfgfs your information">  
</form>

<?php
echo "<h2>Your Input:</h2>";

if (strlen($name) > 0) echo "Name $name <br>";
if (strlen($email) > 0) echo "Email $email <br>";
if (strlen($website) > 0) echo "Website $website <br>";
if (strlen($comment) > 0) echo "Comment: $comment <br>";
if (strlen($gender) > 0) echo "Gender: $gender <br>";
if (strlen($country) > 0) echo "Country: $country <br>";
if (strlen($vechicle) > 0) echo "Vechicle: $vechicle <br>";

?>
</br></br>
<h3> Alerts<h3/>
<button id="alert" onclick= "alertMe()">Alert me</button> 
<button id="confirm" onclick="confirmMe()">Confirm me</button>
<button id="prompt" onclick="promptMe()">Prompt me</button>
<p id="demo"></p>
</br></br>
<h3> links </h3>
<a href="https://bbc.com" > Open Google</a></br>
<a href="https://www.yahoo.com/" target="_blank"><img src="./yahooLogo.jpeg"  style="width:50px;height:50px;"> click the image to open Yahoo page</a>
</br>
</br>
</br>
</br>

<iframe name="w3school" src="http://www.w3schools.com" width="560" height="315">
  <p>Your browser does not support iframes.</p>
</iframe>



</body>
</html>