<?php
// upto line 13 is getting data from registraion page and passing to variables
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";
$customerID=$_POST["customerID"];
$customerName=$_POST["customerName"];
$contactName=$_POST["contactName"];
$address=$_POST["address"];
$city=$_POST["city"];
$postalCode=$_POST["postalCode"];
$country=$_POST["country"];
//echo "$customerName + $address";
//echo "Registraion successfull " ;
// echo "registraion successfull";
//echo "thank you for registration, <br> you reach to our dummy stub database <br>";
//echo $customerID ."--" .$customerName;
//exit;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// this following program is insert the customer to our database 
$sql = "INSERT INTO customers (customerID, customerName, contactName,address, city, postalCode, country)
VALUES ('$customerID', '$customerName', '$contactName','$address', '$country ', '$postalCode', '$city')";

if ($conn->query($sql) === TRUE) {
    echo "Customer registored successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

