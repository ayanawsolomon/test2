<!DOCTYPE HTML>
<html>
<head>
<style>
#cart1,#cart2 {
    width: 150px;
    height: 150px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}


/* Dropdown Button */
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
    display: block;
}
</style>
<script>
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}
</script>
</head>
<body>
<a href="testPage.php">Back to Test Page 1 </a>
<hr/>
<div id="menu" class="dropdown">
  <button class="dropbtn">Dropdown</button>
  <div class="dropdown-content">
    <a href="testPage.php" id ="a" >Link 1</a>
    <a href="testPage.php">Go to Test Page</a>
    <a href="#">Link 3</a>
  </div>
</div>
<p>Drag and drop cources you want to register (Solomon)</p>

<div id="cart1" ondrop="drop(event)" ondragover="allowDrop(event)">
<img id="c1" src="img/C1.png" draggable="true" ondragstart="drag(event)" width="100" height="40"><br/>
<img id="c2" src="img/C2.png" draggable="true" ondragstart="drag(event)" width="100" height="40"><br/>
<img id="c3" src="img/C3.png" draggable="true" ondragstart="drag(event)" width="100" height="40"><br/>

</div>
<br>
<div id="cart2" ondrop="drop(event)" ondragover="allowDrop(event)">

</div>
<a href="img/C1.png" download > click to download the lession</a>
<br>
<hr/>

</body>
</html>
