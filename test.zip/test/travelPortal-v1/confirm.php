<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Flight Confirmation: Mercury Tours</title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: green; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FF6692"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#88888" link="#99777" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#006699">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#006699">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#11111111"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="book.php">Flight</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Hotel</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#000000"><a href="inprogress.php">Car Rent</a></font></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Vacation</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>ABCD ABCD</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#006699" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ON</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTER</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>




<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>

<!--CONTENT REGION START-->
				<table cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
				  <td width="14">
				    
				  </td>
				<td>


<table width="492" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr> 
    <td><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/mast_confirmation.gif" width="492" height="30"></td>
  </tr>
  <tr> 
    <td><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr valign="top"> 
    <td> 
      <p align="left"><font size="2" face="Arial, Helvetica, sans-serif"><b><font size="2" face="Arial, Helvetica, sans-serif"><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/printit.gif" width="57" height="69" align="right"></font><font size="+1">You book your flight successfully</font></b><br>

        <br>
        Thank you for using our service and wish you a naice trip<br>
        <br>
        </font></p>
    </td>
  </tr>
  <tr> 
  </tr><tr valign="top"> 
    <td>

      
      <table width="100%" cellspacing="1" cellpadding="2" border="0" bgcolor="ffffff">
        <tbody><tr align="left"> 
          <td class="frame_header_info" valign="top" nowrap="nowrap" bgcolor="#003399"> 
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
              <tbody><tr>
                <td><b><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="blaCK"><b><font size="2" color="#FFFFFF" face="Arial, Helvetica, sans-serif">&nbsp;Flight 
                  Confirmation # 2017-09-456404564054</font><font size="2" color="#000000" face="Arial, Helvetica, sans-serif"> 
                  </font></b></font></font></b></td>


<td align="right"><font size="2" color="#FFFFFF" face="Arial, Helvetica, sans-serif"><b>
	          2017-09-06 09:04:04.0</b></font></td>

              </tr>
            </tbody></table>
            
          </td>
        </tr>
        <tr align="left"> 
          <td class="frame_header_info" valign="top" nowrap="nowrap" bgcolor="#CCCCCC"><b><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">Departing</font></b></td>
        </tr>
        <tr align="left"> 
          <td class="frame_header_info" valign="top" nowrap="nowrap"> <font size="-1" face="Arial, Helvetica, sans-serif, Verdana"><b>

		    Acapulco to Acapulco</b> <br>
            7/9/2017 @ 5:03 w/ Ethiopian Airline <br>
            Coach<br>
            $2700 each </font></td>
        </tr>
        <tr align="left"> 
          <td class="frame_header_info" valign="top" nowrap="nowrap" bgcolor="#CCCCCC"><b><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">Returning</font></b></td>

        </tr>
        <tr align="left"> 
          <td class="frame_header_info" valign="top" nowrap="nowrap"> <font size="-1" face="Arial, Helvetica, sans-serif, Verdana"><b>
		   Ethiopian Airlien</b> <br>
            7/9/2017 @ 18:45 w/ Ethiopian Airline<br>
            Coach<br>
            $270 each </font></td>

        </tr>
        <tr> 
		     <td class="data_left" bgcolor="#CCCCCC" align="LEFT"><font size="-1" face="Arial, Helvetica, sans-serif, Verdana"><b>Passengers</b></font></td>
          <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
          <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--></tr>
        <tr> 
          <td class="data_left" valign="top" bgcolor="#FFFFFF" align="LEFT"><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">
1 passenger<br>			</font></td>
        </tr>

        <tr align="center"> 
          <td bgcolor="#CCCCCC"> 
            <div align="left"><font size="-1" face="Arial, Helvetica, sans-serif, Verdana"><b>Fee is for</b></font></div>
          </td>
        </tr><tr align="center"> 
          <td valign="top" align="left"> 
            <p><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">
  <br>1300 Coppermine RD.<br><br>Herndon, Va, 20170<br>
              </font><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">
              US  1</font></p>
          </td>
        </tr>
        <tr align="center"> 
          <td bgcolor="#CCCCCC"> 
            <div align="left"><font size="-1" face="Arial, Helvetica, sans-serif, Verdana"><b>Delivery Address / Email</b></font></div>
          </td>
        </tr><tr align="center"> 
          <td valign="top" align="left"> 
            <p><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">
1300 Coppermine RD<br><br>Herndon, Va, 20170<br>
              </font><font size="-1" face="Arial, Helvetica, sans-serif, Verdana">
              </font></p>
          </td>
        </tr>
        <tr bgcolor="#FFCC00" align="right"> 
          <td class="data_left" valign="top">

            <table cellspacing="0" cellpadding="2" border="0">
              <tbody><tr> 
                <td align="right"><b><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="blaCK"><font size="2" color="#000000" face="Arial, Helvetica, sans-serif">Total 
                  TAX:&nbsp; </font></font></font></b></td>
                <td align="right"><font size="2" color="#FFFFFF" face="Arial, Helvetica, sans-serif"><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="blaCK"><b><font size="2" color="#000000" face="Arial, Helvetica, sans-serif">
                $76.9 </font></b></font></font></font></td>
              </tr>
              <tr> 
                <td align="right"><b><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="blaCK"><b><font size="2" color="#000000" face="Arial, Helvetica, sans-serif">Total 
                  Price (plus taxes):&nbsp; </font></b></font></font></b></td>

                <td align="right"><font size="2" color="#FFFFFF" face="Arial, Helvetica, sans-serif"><b><font size="2" face="ARIAL, HELVETICA"><font size="-1" color="blaCK"><b><font size="2" color="#000000" face="Arial, Helvetica, sans-serif">
                $1984 </font></b></font></font></b></font></td>
              </tr>
            </tbody></table>
          </td>
        </tr>
      </tbody></table>
         </td>

        </tr>
        <tr> 
          <td colspan="2"> 
				<div align="right"><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></div>
          </td>
        </tr>
        <tr> 
    <td align="left"> &nbsp;
    <table width="100%" cellspacing="0" cellpadding="2" border="0">
     <tbody><tr align="center"> 
    <td align="right">

			<a href="selectFlight.php"><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/backtoflights.gif" width="126" height="23" border="0"> </a>
		</td>
    <td align="right">
			<a href="http://home.php"><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/home.gif" width="118" height="23" border="0"> </a>
	   </td>
    <td align="right">
			<a href="login.php"><img src="Flight%20Confirmation%20%20Mercury%20Tours_files/Logout.gif" width="118" height="23" border="0"> </a>

	   </td>
	   </tr>
    </tbody></table>
		</td>
		</tr>
      </tbody></table>
    
  </td></tr><tr>
    
  <td>&nbsp;</td>
</tr>


				
				
				</tbody></table>

<!--CONTENT REGION END-->

        </td>
      </tr>
     <tr>
      <td>

<!--FOOTER REGION START-->


<!--FOOTER REGION START-->
<div class="footer">
� 2005, Mercury Interactive (v. 011003-1.01-058)
</div>
<!--FOOTER REGION END-->


<!--FOOTER REGION END-->

      </td>
     </tr>

      
    
  </tbody></table>
</td></tr></tbody></table>
</div>


</body></html>