<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "travelPortal";
$userName=$_POST["userName"];
$password=$_POST["password"];

// Create connection

$conn = new mysqli($dbservername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "SELECT count(*) as no FROM registration WHERE loginName='$userName' and password='$password'";

if ($result=$conn->query($sql)) {
	$row = $result->fetch_assoc();
	if($row["no"] >1){
	header( 'Location: ../searchFlight.php' );
	}else {
		echo "Wrong user name and password, try again";

	}
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>