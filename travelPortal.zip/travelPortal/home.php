<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Welcome: Mercury Tours</title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: green; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FF6692"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#88888" link="#99777" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#006699">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#006699">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#11111111"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="book.php">Flights</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Hotels</a></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><font color="#000000"><a href="inprogress.php">Car Rent</a></font></td>
</tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FF9992"><a href="inprogress.php">Vacation</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>ABCD ABCD</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#006699" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ONN</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTOR</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>




<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>

<!--CONTENT REGION START-->
				<table cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
				  <td width="14">
				    
				  </td>
				<td>

<table width="492" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>  </tr>
  <tr>
    <td width="273" valign="top"> 
      <p><img src="Welcome%20%20Mercury%20Tours_files/featured_destination.gif" alt="Featured Destination: Aruba" width="273" height="298"></p>
      <table width="100%" cellspacing="0" cellpadding="0" border="0">
        <tbody><tr> 
          <td width="273"><img src="Welcome%20%20Mercury%20Tours_files/hdr_specials.gif" alt="Specials" width="270" height="20"></td>
        </tr>
        <tr>

          <td><img src="Welcome%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
        </tr>
        <tr valign="top"> 
          <td height="101">
            <table width="270" cellspacing="0" cellpadding="2" border="0">
              <tbody><tr bgcolor="#CCCCCC"> 
                <td width="80%"><font size="2" face="Arial, Helvetica, sans-serif, Verdana">Addis Ababa, Ethiopia</font></td>
                <td width="20%">
                  <div align="right"><font size="2" face="Arial, Helvetica, sans-serif, Verdana"><b>$2000</b></font></div>

                </td>
              </tr>
              <tr>
                <td width="80%" height="10"><font size="2" face="Arial, Helvetica, sans-serif">Stockholm, Sweden</font></td>
                <td width="20%" height="10">
                  <div align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>$1600</b></font></div>
                </td>
              </tr>

              <tr bgcolor="#CCCCCC">
                <td width="80%"><font size="2" face="Arial, Helvetica, sans-serif">Paris, France</font></td>
                <td width="20%">
                  <div align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>$2000</b></font></div>
                </td>
              </tr>
              <tr>
                <td width="80%"><font size="2" face="Arial, Helvetica, sans-serif">Miyami, Florida</font></td>

                <td width="20%">
                  <div align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>$600</b></font></div>
                </td>
              </tr>
              <tr bgcolor="#CCCCCC"> 
                <td width="80%" height="19"><font size="2" face="Arial, Helvetica, sans-serif">Gondar, Ethiopia </font></td>
                <td width="20%" height="19">
                  <div align="right"><font size="2" face="Arial, Helvetica, sans-serif"><b>$2350</b></font></div>

                </td>
              </tr>
            </tbody></table>
          </td>
        </tr>
      </tbody></table>

      <table width="277" cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>

          <td colspan="2"><br>
            <img src="Welcome%20%20Mercury%20Tours_files/hdr_tips.gif" alt="Tour Tips" width="270" height="20"></td>
        </tr>
        <tr>
          <td colspan="2" width="274"><img src="Welcome%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
        </tr>
        <tr>
          <td width="84"><img src="Welcome%20%20Mercury%20Tours_files/tip93.gif" alt="Tip#93" width="70" height="47"></td>
          <td width="190" valign="top"><font size="2" face="Arial, Helvetica">Make sure you have safety bag under your seat</font></td>

        </tr>
      </tbody></table>
      <p>&nbsp; </p>
      <p>&nbsp; </p>
    </td>
    <td width="216">&nbsp;&nbsp;&nbsp;</td>
    <td width="192" valign="top">
<!-- the following progrma is to create test page -->	
      <form method="post" action="scripts/login1.php" name="home">
	<input name="action" value="process" type="hidden">
        <table width="192" cellspacing="0" cellpadding="0" border="0">
          <tbody><tr align="right">
            <td colspan="2"><font size="2" face="Arial, Helvetica, sans-serif, Verdana"><b>Jul 6, 2017</b></font></td>
          </tr>
          <tr>
            <td colspan="2"><img src="Welcome%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
          </tr>
          <tr>

            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_findflight.gif" alt="Find a Flight" width="88" height="20"></td>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_right.gif" width="104" height="20"></td>
          </tr>
          <tr>
            <td colspan="2"> 
              <table width="100%" cellspacing="0" cellpadding="3" border="0">
                <tbody><tr>
                  <td colspan="2"><font size="2" face="Arial, Helvetica, sans-serif">Lowest flight benefit is available here only for only registored customers.</font> </td>

                </tr>
                <tr>
                  <td align="right"><font size="2" face="Arial, Helvetica, sans-serif">Login Name: </font></td>
                  <td width="112">
                    <input name="userName" size="10" type="text">
                  </td>
                </tr>
                <tr>

                  <td align="right"><font size="2" face="Arial, Helvetica, sans-serif">Login Pass:</font></td>
                  <td width="112">
                    <input name="password" size="10" type="password">
                  </td>
                </tr>
                <tr>
                  <td align="right">&nbsp;</td>
                  <td width="112"> 
                    <div align="center"><input name="login" value="Login" src="Welcome%20%20Mercury%20Tours_files/btn_signin.gif" alt="Sign-In" width="58" type="image" height="17" border="0">

					</div>
                  </td>
                </tr>
                <tr>
                  <td colspan="2"><img src="Welcome%20%20Mercury%20Tours_files/spacer.htm" width="1" height="2"></td>
                </tr>
              </tbody></table>
            </td>
          </tr>

          <tr>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_destinations.gif" alt="Desinations" width="88" height="20"></td>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_right.gif" width="104" height="20"></td>
          </tr>
          <tr>
            <td colspan="2"> 
              <table width="100%" cellspacing="0" cellpadding="3" border="0">
                <tbody><tr>
                  <td width="80" align="center"><img src="Welcome%20%20Mercury%20Tours_files/icn_destinations.gif" width="34" height="34"></td>

                  <td width="100"><font size="2" face="Arial, Helvetica, sans-serif, Verdana">Click here to get more information about your destination <a href="inprogress.php">your destination</a>.</font> 
                  </td>
                </tr>
              </tbody></table>
            </td>
          </tr>
          <tr>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_vacation.gif" alt="vacations" width="88" height="20"></td>

            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_right.gif" width="104" height="20"></td>
          </tr>
          <tr>
            <td colspan="2"> 
              <table width="100%" cellspacing="0" cellpadding="3" border="0">
                <tbody><tr>
                  <td width="80" align="center"><img src="Welcome%20%20Mercury%20Tours_files/icn_vacations.gif" width="40" height="37"></td>
                  <td width="100"><font size="2" face="Arial, Helvetica, sans-serif, Verdana">Look here to see for summer time vacation offers</a>.</font></td>

                </tr>
              </tbody></table>
            </td>
          </tr>
          <tr>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_register.gif" alt="Register" width="88" height="20"></td>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_right.gif" width="104" height="20"></td>
          </tr>
          <tr>

            <td colspan="2"> 
              <table width="100%" cellspacing="0" cellpadding="3" border="0">
                <tbody><tr>
                  <td width="80" align="center"><img src="Welcome%20%20Mercury%20Tours_files/icn_register.gif" width="42" height="35"></td>
                  <td width="100"><font size="2" face="Arial, Helvetica, sans-serif, Verdana"><a href="http://newtours.demoaut.com/mercuryregister.php">Register 
                    here</a> to join Mercury Tours!</font> </td>
                </tr>
              </tbody></table>

            </td>
          </tr>
          <tr>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_links.gif" alt="Links" width="88" height="20"></td>
            <td><img src="Welcome%20%20Mercury%20Tours_files/hdr_right.gif" width="104" height="20"></td>
          </tr>
          <tr>
            <td colspan="2"> 
              <table width="100%" cellspacing="0" cellpadding="3" border="0">

                <tbody><tr>
                  <td> <font size="2" face="Arial, Helvetica, sans-serif, Verdana"> <br>
                    <a href="http://businesstravel.about.com/mbody.htm?PM=78_101_T&amp;cob=home">Solo Flight @ Portal.com</a><br>
                </tr>
              </tbody></table>
            </td>

          </tr>
        </tbody></table>
      </form>
      <p>&nbsp; </p>
    </td>
  </tr>
</tbody></table>
				</td>
				</tr>

				</tbody></table>

<!--CONTENT REGION END-->

        </td>
      </tr>
     <tr>
      <td>

<!--FOOTER REGION START-->


<!--FOOTER REGION START-->
<div class="footer">
� 2017, Solo Travel Portal(v. 301-73X-3908)
</div>
<!--FOOTER REGION END-->


<!--FOOTER REGION END-->

      </td>
     </tr>
      
    

  </tbody></table>
</td></tr></tbody></table>
</div>

</body></html>