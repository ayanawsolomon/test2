<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "travelPortal";
$firstName=$_POST["firstName"];
$midleInitial=$_POST["midleInitial"];
$lastName=$_POST["lastName"];
$phone=$_POST["phone"];
$email=$_POST["email"];
$address1=$_POST["address1"];
$city=$_POST["city"];
$postalCode=$_POST["postalCode"];
$country=$_POST["country"];
$loginName=$_POST["loginName"];
$password=$_POST["password"];
$confirmPassword=$_POST["confirmPassword"];

//echo "registraion successfull";
//exit;
// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO registration (firstName, midleInitial,LastName,phone,email,address1, city,country,postalCode, loginName,password)
VALUES ('$firstName', '$midleInitial','$lastName','$phone', '$email', '$address1', '$city', '$country','$postalCode', '$loginName', '$password')";

if ($conn->query($sql) === TRUE) {
	echo "Welcome $firstName registored successfully.<br/>";
	echo "Now you can naviage back and login with your Credencials<br/>";
	echo "usr userName =$loginName<br/>";
	echo " password =$password</br>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

