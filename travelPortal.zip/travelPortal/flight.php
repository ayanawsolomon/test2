<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Select a Flight: Mercury Tours</title>
<script language="JavaScript">
function changeStyle(obj, new_style) {
obj.className = new_style
}
</script>
<style type="text/css">
.menu {
BACKGROUND-COLOR: white; BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: hidden
}
.visibleMenu {
BORDER-BOTTOM: COLOR: menutext; CURSOR: default; FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10pt; LINE-HEIGHT: 100%; POSITION: absolute; VISIBILITY: visible
}
.menuItem {
POSITION: relative; COLOR: menutext; TEXT-DECORATION: none
}
.menuItemOver {
POSITION: relative; COLOR: highlighttext; TEXT-DECORATION: none
}
.menuItemOver A {
POSITION: relative; COLOR: highlighttext; CURSOR: default; TEXT-DECORATION: none
}
.menuItem A {
POSITION: relative; COLOR: menutext; CURSOR: default; TEXT-DECORATION: none
}
.more {
FONT-FAMILY: WebDings; POSITION: relative; TEXT-ALIGN: right; Z-INDEX: 100
}
.mouseOut {BACKGROUND: orange; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt;align="center"}
.mouseOver {BACKGROUND: "#FFC455"; FONT-Weight: bold;FONT-FAMILY: Helvetica; FONT-SIZE: 8pt; align="center"}
</style></head>
<body vlink="#666666" link="#000099" bgcolor="#FFFFFF">

<div>
<table height="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td valign="top" bgcolor="#003366">      <table cellspacing="0" cellpadding="0" border="0">
    <tbody><tr><td halign="center" valign="top" bgcolor="#003366">

<!--NAVIGATION BAR REGION START-->
<table width="110" cellspacing="0" cellpadding="8" border="0" align="center">
<tbody><tr valign="top">
<td>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/logo.gif" alt="Mercury Tours" width="100" height="110"><br>	  </p>
<table cellspacing="0" cellpadding="2" bordercolor="#000000" border="2" align="center">
<tbody><tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><font color="#000000"><a href="home.php">Home</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><a href="book.php">Flights</a></td></tr>

<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><a href="inprogress.php">Hotels</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><font color="#000000"><a href="inprogress.php">Car Rentals</a></font></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><a href="cruise.php">Cruises</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>

<td width="80" height="19" bgcolor="#FFC455"><a href="inprogress.php">Destinations</a></td>
</tr>
<tr class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')">
<td width="20" height="19"></td>
<td width="80" height="19" bgcolor="#FFC455"><a href="inprogress.php">Vacations</a></td>
</tr></tbody></table>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/html.gif" width="100" height="61" border="0">
<font size="1" color="white" face="Arial, Helvetica, sans-serif"><u>Use Java Version</u></font></p>
<p align="center"><img src="Welcome%20%20Mercury%20Tours_files/boxad1.gif" width="88" height="78"></p>
</td></tr>
</tbody></table>

<!--NAVIGATION BAR REGION END-->

    </td>
		</tr></tbody></table>
    </td>
    <td valign="top">
      <table cellspacing="0" cellpadding="0" border="0">
        <tbody><tr>
          <td height="63" bgcolor="#003366">

<!--AD REGION START-->
<img src="Welcome%20%20Mercury%20Tours_files/banner2.gif" width="488" vspace="4" hspace="8" height="63" border="0">

<!--AD REGION END-->

          </td>
       </tr>
      <tr>
        <td height="16" bgcolor="#FF9900" align="right">



<!--HEADER REGION START-->
<table height=" 16" cellspacing="0" cellpadding="0" bordercolor="#000000" border="1" background="Welcome%20%20Mercury%20Tours_files/black.htm">
  <tbody><tr>

    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="67" height="33" align="center"><a href="login.php">SIGN-ON</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="77" height="33" align="center"><a href="register.php">REGISTER</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="73" height="33" align="center"><a href="inprogress.php">HELP</a></td>
    <td class="mouseOut" onmouseout="changeStyle(this, 'mouseOut')" onmouseover="changeStyle(this, 'mouseOver')" width="74" height="33" align="center"><a href="inprogress.php">CONTUC-US</a></td>
  </tr>
</tbody></table>


<!--HEADER REGION END-->

        </td>
      </tr>
      <tr>
        <td height="14" align="right">



<!--Space REGION START-->

<!--Space REGION END-->

        </td>

      </tr>
      <tr>
        <td>

<!--CONTENT REGION START-->
				<table cellspacing="0" cellpadding="0" border="0">
				<tbody><tr>
				  <td width="14">
				    
				  </td>
				<td>


<table width="492" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr> 
    <td><img src="Select%20a%20Flight%20%20Mercury%20Tours_files/mast_selectflight.gif" width="492" height="30"></td>
  </tr>
  <tr> 
    <td><img src="Select%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="10"></td>
  </tr>
  <tr> 
    <td><font size="2" face="Arial, Helvetica, sans-serif">Select your departure 
      and return flight from the selections below. Your total price will be higher 
      than quoted if you elect to fly on a different airline for both legs of 
      your travel.</font></td>
  </tr>

  <tr>
    <td><img src="Select%20a%20Flight%20%20Mercury%20Tours_files/spacer.htm" width="1" height="5"></td>
  </tr>
  <tr> 
    <td> 
      <form method="post" action="mercurypurchase.php" name="results">
	<input name="fromPort" value="Acapulco" type="hidden">
	<input name="toPort" value="Acapulco" type="hidden">
	<input name="passCount" value="1" type="hidden">
	<input name="toDay" value="6" type="hidden">
	<input name="toMonth" value="7" type="hidden">
	<input name="fromDay" value="6" type="hidden">
	<input name="fromMonth" value="7" type="hidden">
	<input name="servClass" value="Coach" type="hidden">
        <table width="100%" cellspacing="1" cellpadding="2" border="0" bgcolor="ffffff">
          <tbody><tr>
             <td colspan="5" valign="top"> 
              <table width="100%" cellspacing="2" cellpadding="0" border="0">

<tbody><tr> 
                  <td class="title" valign="BOTTOM" align="LEFT"><font face="Arial, Helvetica, sans-serif"><b><font color="#FF9900">DEPART</font></b></font></td>
                  <td class="title" valign="BOTTOM" align="RIGHT">&nbsp;</td>
                </tr>
                <tr> 
                  <td class="title" valign="BOTTOM" align="LEFT"><b><font size="2" color="#333333" face="ARIAL">	
                    Acapulco to Acapulco</font></b></td>
                  <td class="title" valign="BOTTOM" align="RIGHT"><b><font size="2" color="#333333" face="ARIAL">
				         7/6/2017</font></b></td>

                </tr>
              </tbody></table>
            </td>
          </tr>
          <tr> 
            <td class="frame_header_action" nowrap="nowrap" bgcolor="#CCCCCC" align="CENTER"><font size="-2" color="#000000" face="ARIAL">SELECT</font></td>
            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">FLIGHT</font></td>
            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">DEPART</font></td>

            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">STOPS</font></td>
          		  
	         </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input checked="checked" name="outFlight" value="Blue Skies Airlines$360$270$5:03" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Blue Skies Airlines 360 </b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">

            5:03</font><br>
            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $270</b> (based on round trip)</font></font></td>

          </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="outFlight" value="Blue Skies Airlines$361$271$7:10" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Blue Skies Airlines 361</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            7:10</font><br>

            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $271</b> (based on round trip)</font></font></td>
          </tr>

	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="outFlight" value="Pangea Airlines$362$274$9:17" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Pangaea Airlines 362</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            9:17</font><br>
            </td>

            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $274</b> (based on round trip)</font></font></td>
          </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="outFlight" value="Unified Airlines$363$281$11:24" type="radio">

            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Unified Airlines 363</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            11:24</font><br>
            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->

	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $281</b> (based on round trip)</font></font></td>
          </tr>
		 </tbody></table>
        <table width="100%" cellspacing="1" cellpadding="2" border="0" bgcolor="ffffff">
          <tbody><tr>
             <td colspan="5" valign="top"> 
              <table width="100%" cellspacing="2" cellpadding="0" border="0">

<tbody><tr> 
                  <td class="title" valign="BOTTOM" align="LEFT"><font face="Arial, Helvetica, sans-serif"><b><font color="#FF9900">RETURN</font></b></font></td>
                  <td class="title" valign="BOTTOM" align="RIGHT">&nbsp;</td>
                </tr>
                <tr> 
                  <td class="title" valign="BOTTOM" align="LEFT"><b><font size="2" color="#333333" face="ARIAL">	
                    Acapulco to Acapulco</font></b></td>
                  <td class="title" valign="BOTTOM" align="RIGHT"><b><font size="2" color="#333333" face="ARIAL">
				         7/6/2017</font></b></td>

                </tr>
              </tbody></table>
            </td>
          </tr>
          <tr> 
            <td class="frame_header_action" nowrap="nowrap" bgcolor="#CCCCCC" align="CENTER"><font size="-2" color="#000000" face="ARIAL">SELECT</font></td>
            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">FLIGHT</font></td>
            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">DEPART</font></td>

            <td class="frame_header_info" nowrap="nowrap" bgcolor="#003399" align="CENTER"><font size="-2" color="#FFFFFF" face="ARIAL">STOPS</font></td>
          		  
	         </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input checked="checked" name="inFlight" value="Blue Skies Airlines$630$270$12:23" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Blue Skies Airlines 630</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">

            12:23</font><br>
            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $270</b> (based on round trip)</font></font></td>

          </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="inFlight" value="Blue Skies Airlines$631$273$14:30" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Blue Skies Airlines 631</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            14:30</font><br>

            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $273</b> (based on round trip)</font></font></td>
          </tr>

	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="inFlight" value="Pangea Airlines$632$282$16:37" type="radio">
            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Pangea Airlines 632</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            16:37</font><br>
            </td>

            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->
	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $282</b> (based on round trip)</font></font></td>
          </tr>
	     <tr> 
            <td class="frame_action_xrows" rowspan="2" valign="CENTER" bgcolor="#FFCC00" align="CENTER"> 
              <input name="inFlight" value="Unified Airlines$633$303$18:44" type="radio">

            </td>
            <td class="data_left" bgcolor="CCCCCC" align="LEFT"><font size="-1" face="ARIAL"><b> 
				Unified Airlines 633</b></font></td>
            <td class="data_center_mono" valign="TOP" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">
            18:44</font><br>
            </td>
            <td class="data_center" nowrap="nowrap" bgcolor="CCCCCC" align="CENTER"><font size="-1" face="ARIAL">non-stop</font></td>
            <!--<TD class=data_center ALIGN=CENTER BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>--> 
            <!--<TD class=data_right  ALIGN=RIGHT BGCOLOR=CCCCCC NOWRAP><FONT SIZE=-1 FACE=ARIAL>&nbsp</FONT></TD>-->

	     </tr>
          <tr> 
            <td class="data_verb_xcols" colspan="4" valign="top" bgcolor="#FFFFFF"><font size="-1"><font color="#333333" face="arial"><b>Price: 
              $303</b> (based on round trip)</font></font></td>
          </tr>
		 </tbody></table>



<p align="center">&nbsp;&nbsp;

<input name="reserveFlights" src="Select%20a%20Flight%20%20Mercury%20Tours_files/continue.gif" width="104" type="image" height="23" border="0"></p>
      </form>
    </td>
  </tr>
</tbody></table>

				</td>
				</tr>
				</tbody></table>

<!--CONTENT REGION END-->

        </td>
      </tr>
     <tr>
      <td>

<!--FOOTER REGION START-->


<!--FOOTER REGION START-->
<div class="footer">
� 2005, Mercury Interactive (v. HG-0.15)

</div>
<!--FOOTER REGION END-->


<!--FOOTER REGION END-->

      </td>
     </tr>
      
    
  </tbody></table>
</td></tr></tbody></table>

</div>


</body></html>